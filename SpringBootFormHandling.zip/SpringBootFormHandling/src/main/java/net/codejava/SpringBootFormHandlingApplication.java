package net.codejava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootFormHandlingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootFormHandlingApplication.class, args);
	}

}
